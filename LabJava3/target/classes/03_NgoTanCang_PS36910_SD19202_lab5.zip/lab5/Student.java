/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab5;

/**
 *
 * @author acer
 */
public class Student {

    String maSV;
    String hoTen;
    String email;
    String soDT;
    String diaChi;
    int gioiTinh;

    public Student() {
    }

    public Student(String maSV, String hoTen, String email, String soDT, int gioiTinh, String diaChi) {
        this.maSV = maSV;
        this.hoTen = hoTen;
        this.email = email;
        this.soDT = soDT;
        this.gioiTinh = gioiTinh;
        this.diaChi = diaChi;

    }

}
