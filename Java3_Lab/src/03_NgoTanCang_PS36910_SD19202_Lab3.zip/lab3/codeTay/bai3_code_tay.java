package lab3.codeTay;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

public class bai3_code_tay {
    public bai3_code_tay() {
        CreateJFrame();
    }

    public void CreateJFrame() {
        JFrame frame = new JFrame();
        frame.setSize(700, 600);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        // khai bao paneel
        JPanel pn1, pn2, pn3, pn4;
        // khai bao va add element vao panel 1
        pn1 = new JPanel(new FlowLayout());
        pn1.setBounds(0, 0, 700, 200);
        pn1.setBorder(new TitledBorder(new EmptyBorder(0, 50, 0, 50), "Personnal detail"));
        JPanel pn1_no1 = new JPanel(new GridLayout(4, 1));
        JPanel pn1_no2 = new JPanel(new GridLayout(4, 1));
        pn1_no1.setBounds(0, 0, 200, 100);
        pn1_no2.setBounds(0, 0, 500, 100);
        JLabel lblFristName, lblLastName, blbContact, lblAddress;
        JTextField txtFristName, txtLastName, txtContact;
        JTextArea txtAddress;
        // jlabel
        lblFristName = new JLabel("Frist Name");
        lblLastName = new JLabel("Last Name");
        blbContact = new JLabel("Contact");
        lblAddress = new JLabel("Address");
        // textfield
        txtFristName = new JTextField(20);
        txtFristName.setPreferredSize(new Dimension(50, 20));
        txtLastName = new JTextField(20);
        txtLastName.setPreferredSize(new Dimension(50, 20));
        txtContact = new JTextField(20);
        txtContact.setPreferredSize(new Dimension(50, 20));
        txtAddress = new JTextArea(3, 5);
        txtAddress.setPreferredSize(new Dimension(50, 40));
        txtAddress.setBackground(Color.BLACK);

        // add pn1_no1
        pn1_no1.add(lblFristName);
        pn1_no1.add(lblLastName);
        pn1_no1.add(blbContact);
        pn1_no1.add(lblAddress);

        // add pn1_no2
        pn1_no2.add(txtFristName);
        pn1_no2.add(txtLastName);
        pn1_no2.add(txtContact);
        pn1_no2.add(txtAddress);
        // add pn1
        pn1.add(pn1_no1);
        pn1.add(pn1_no2);

        // tao va add element vao panel 2
        pn2 = new JPanel();

        // panel 3;
        pn3 = new JPanel();

        // panel 4;
        pn4 = new JPanel();

        // hien thi frame
        frame.add(pn1);
        frame.add(pn2);
        frame.add(pn3);
        frame.add(pn4);
        frame.setVisible(true);

    }

    public static void main(String[] args) {
        new bai3_code_tay();
    }
}
